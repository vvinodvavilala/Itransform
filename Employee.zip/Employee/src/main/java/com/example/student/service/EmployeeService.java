package com.example.student.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.student.model.EmployeeModel;
import com.example.student.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository repo;
	
	public ArrayList<EmployeeModel> findall(){
		return (ArrayList<EmployeeModel>)repo.findAll();
		
	}

}
